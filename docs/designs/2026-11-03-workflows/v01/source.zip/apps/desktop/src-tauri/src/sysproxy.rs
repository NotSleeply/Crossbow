//! 系统代理管理：按平台后端设置/还原系统级代理，带崩溃兜底 journal。
//!
//! 兜底思路（DESIGN §4.4 状态一致性守护）：开启成功后把状态写入 journal
//! 文件；正常关闭/退出时清除。若上次会话异常退出（journal 残留），本次启动
//! 先执行一次全量还原——保证「任何路径退出都不留脏系统代理」。

use std::collections::BTreeMap;
use std::path::PathBuf;
use std::sync::Mutex;

use serde::{Deserialize, Serialize};

/// 默认绕过列表（本机/局域网直连）。
#[cfg(target_os = "macos")]
const BYPASS_DOMAINS: &[&str] = &[
    "127.0.0.1",
    "localhost",
    "192.168.0.0/16",
    "10.0.0.0/8",
    "172.16.0.0/12",
    "*.local",
    "*.crashlytics.com",
];

pub trait SysProxyBackend: Send + Sync {
    /// 枚举可设置代理的网络服务。
    fn list_services(&self) -> Result<Vec<String>, String>;
    /// 为单个服务开启代理（HTTP/HTTPS/SOCKS → 127.0.0.1:port + bypass）。
    fn enable_service(&self, service: &str, port: u16) -> Result<(), String>;
    /// 为单个服务全量关闭三类代理（无快照时的兜底路径）。
    fn disable_service(&self, service: &str) -> Result<(), String>;
    /// 读取单个服务当前的三类代理设置（开启前快照用）。
    fn service_snapshot(&self, service: &str) -> Result<ServiceSnapshot, String>;
    /// 按快照还原单个服务设置。
    fn restore_service(&self, service: &str, snap: &ServiceSnapshot) -> Result<(), String>;
}

/// macOS `networksetup` 实现。
#[cfg(target_os = "macos")]
pub struct NetworkSetup;

#[cfg(target_os = "macos")]
impl NetworkSetup {
    fn run(args: &[&str]) -> Result<String, String> {
        let out = std::process::Command::new("networksetup")
            .args(args)
            .output()
            .map_err(|e| format!("run networksetup: {e}"))?;
        if !out.status.success() {
            return Err(format!(
                "networksetup {}: {}",
                args.join(" "),
                String::from_utf8_lossy(&out.stderr).trim()
            ));
        }
        Ok(String::from_utf8_lossy(&out.stdout).to_string())
    }
}

#[cfg(target_os = "macos")]
impl SysProxyBackend for NetworkSetup {
    fn list_services(&self) -> Result<Vec<String>, String> {
        let out = Self::run(&["-listallnetworkservices"])?;
        Ok(parse_services(&out))
    }

    fn enable_service(&self, service: &str, port: u16) -> Result<(), String> {
        let port = port.to_string();
        for setter in [
            "-setwebproxy",
            "-setsecurewebproxy",
            "-setsocksfirewallproxy",
        ] {
            Self::run(&[setter, service, "127.0.0.1", &port])?;
        }
        let mut args = vec!["-setproxybypassdomains", service];
        args.extend(BYPASS_DOMAINS.iter().copied());
        Self::run(&args)?;
        Ok(())
    }

    fn disable_service(&self, service: &str) -> Result<(), String> {
        for setter in [
            "-setwebproxystate",
            "-setsecurewebproxystate",
            "-setsocksfirewallproxystate",
        ] {
            Self::run(&[setter, service, "off"])?;
        }
        Ok(())
    }

    fn service_snapshot(&self, service: &str) -> Result<ServiceSnapshot, String> {
        Ok(ServiceSnapshot {
            windows: None,
            web: parse_endpoint(&Self::run(&["-getwebproxy", service])?),
            secure: parse_endpoint(&Self::run(&["-getsecurewebproxy", service])?),
            socks: parse_endpoint(&Self::run(&["-getsocksfirewallproxy", service])?),
            bypass: Some(
                parse_bypass_domains(&Self::run(&["-getproxybypassdomains", service])?).join("\n"),
            ),
        })
    }

    fn restore_service(&self, service: &str, snap: &ServiceSnapshot) -> Result<(), String> {
        let apply =
            |setter: &str, state_setter: &str, ep: Option<&ProxyEndpoint>| -> Result<(), String> {
                match ep {
                    Some(ep) => {
                        Self::run(&[setter, service, &ep.host, &ep.port.to_string()])?;
                        Ok(())
                    }
                    None => Self::run(&[state_setter, service, "off"]).map(|_| ()),
                }
            };
        apply("-setwebproxy", "-setwebproxystate", snap.web.as_ref())?;
        apply(
            "-setsecurewebproxy",
            "-setsecurewebproxystate",
            snap.secure.as_ref(),
        )?;
        apply(
            "-setsocksfirewallproxy",
            "-setsocksfirewallproxystate",
            snap.socks.as_ref(),
        )?;
        if let Some(bypass) = &snap.bypass {
            let domains = bypass.lines().collect::<Vec<_>>();
            let mut args = vec!["-setproxybypassdomains", service];
            if domains.is_empty() {
                args.push("Empty");
            } else {
                args.extend(domains);
            }
            Self::run(&args)?;
        }
        Ok(())
    }
}

#[cfg(windows)]
#[path = "sysproxy_windows.rs"]
mod windows;
#[cfg(windows)]
pub use windows::WinInet;

/// 非 macOS 且非 Windows 平台桩：保持编译通过。
#[cfg(not(any(target_os = "macos", windows)))]
pub struct UnsupportedBackend;

#[cfg(not(any(target_os = "macos", windows)))]
impl SysProxyBackend for UnsupportedBackend {
    fn list_services(&self) -> Result<Vec<String>, String> {
        Err("sysproxy: platform backend not implemented yet".into())
    }
    fn enable_service(&self, _: &str, _: u16) -> Result<(), String> {
        Err("sysproxy: platform backend not implemented yet".into())
    }
    fn disable_service(&self, _: &str) -> Result<(), String> {
        Err("sysproxy: platform backend not implemented yet".into())
    }
    fn service_snapshot(&self, _: &str) -> Result<ServiceSnapshot, String> {
        Err("sysproxy: platform backend not implemented yet".into())
    }
    fn restore_service(&self, _: &str, _: &ServiceSnapshot) -> Result<(), String> {
        Err("sysproxy: platform backend not implemented yet".into())
    }
}

#[cfg(target_os = "macos")]
pub(crate) type PlatformBackend = NetworkSetup;
#[cfg(windows)]
pub(crate) type PlatformBackend = WinInet;
#[cfg(not(any(target_os = "macos", windows)))]
pub(crate) type PlatformBackend = UnsupportedBackend;

#[derive(Debug, Clone, Copy, Serialize)]
pub struct SysProxyStatus {
    pub enabled: bool,
    pub port: u16,
}

/// 单个代理槽位的原设置（HTTP/HTTPS/SOCKS 各一）。
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProxyEndpoint {
    pub host: String,
    pub port: u16,
}

/// Preserve Windows per-connection settings verbatim, including PAC/WPAD.
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct WindowsProxyConfig {
    pub flags: u32,
    pub server: String,
    pub bypass: String,
    pub pac_url: String,
}

#[cfg(any(windows, test))]
impl WindowsProxyConfig {
    pub fn endpoint(&self, protocol: &str) -> Option<ProxyEndpoint> {
        if self.flags & 2 == 0 {
            return None;
        } // PROXY_TYPE_PROXY
        let raw = if self.server.contains('=') {
            self.server
                .split(';')
                .filter_map(|entry| entry.trim().split_once('='))
                .find(|(name, _)| name.trim().eq_ignore_ascii_case(protocol))?
                .1
        } else {
            &self.server
        };
        let (host, port) = raw.trim().rsplit_once(':')?;
        Some(ProxyEndpoint {
            host: host.trim().trim_matches(['[', ']']).to_string(),
            port: port.parse().ok()?,
        })
    }
}

/// 一个网络服务的代理设置快照；None = 该槽位原本关闭。
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct ServiceSnapshot {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub windows: Option<WindowsProxyConfig>,
    pub web: Option<ProxyEndpoint>,
    pub secure: Option<ProxyEndpoint>,
    pub socks: Option<ProxyEndpoint>,
    /// Windows：ProxyOverride 原文；macOS：逐行保存的绕过域名。
    #[serde(default)]
    pub bypass: Option<String>,
}

/// journal v2：开启前的原设置快照，disable 时优先还原快照（保住第三方客户端
/// 的配置），无快照才退回全量关闭。
#[derive(Debug, Serialize, Deserialize)]
struct Journal {
    port: u16,
    snapshot: BTreeMap<String, ServiceSnapshot>,
}

pub struct SysProxyManager<B: SysProxyBackend = PlatformBackend> {
    backend: B,
    /// Some(port) = 已开启。
    state: Mutex<Option<u16>>,
    journal_path: PathBuf,
}

/// The exact system proxy state before TUN took ownership of routing. Persisted
/// until TUN is disabled so a restart or failed startup can restore it.
#[derive(Serialize, Deserialize)]
pub(crate) struct SuspendedSysProxy {
    snapshot: BTreeMap<String, ServiceSnapshot>,
    journal: Option<Vec<u8>>,
    enabled_port: Option<u16>,
}

impl<B: SysProxyBackend> SysProxyManager<B> {
    fn tun_journal_path(&self) -> PathBuf {
        self.journal_path.with_file_name("tun-proxy-journal.json")
    }

    pub fn new(backend: B, journal_path: PathBuf) -> Self {
        Self {
            backend,
            state: Mutex::new(None),
            journal_path,
        }
    }

    /// 对所有网络服务开启代理。先保存完整快照与恢复日志；任一服务设置
    /// 失败时回滚全部服务，避免留下 HTTP/HTTPS/SOCKS 半配置状态。
    pub fn enable(&self, port: u16) -> Result<(), String> {
        // A previous attempt may have changed some services before its
        // rollback failed. Recover that snapshot before taking a new one;
        // otherwise the original settings would be overwritten permanently.
        if self.journal_path.exists() {
            self.disable()?;
        }
        let services = self.backend.list_services()?;
        if services.is_empty() {
            return Err("no network services found".into());
        }
        let mut snapshot = BTreeMap::new();
        for svc in &services {
            snapshot.insert(svc.clone(), self.backend.service_snapshot(svc)?);
        }
        // 写盘必须发生在任何 networksetup 修改之前，异常退出也能恢复。
        self.write_journal(port, &snapshot)?;
        for svc in &services {
            if let Err(error) = self.backend.enable_service(svc, port) {
                let mut rollback_errors = Vec::new();
                for (name, original) in &snapshot {
                    if let Err(restore_error) = self.backend.restore_service(name, original) {
                        rollback_errors.push(format!("{name}: {restore_error}"));
                    }
                }
                if rollback_errors.is_empty() {
                    if let Err(remove_error) = std::fs::remove_file(&self.journal_path) {
                        rollback_errors.push(format!("清理恢复日志失败: {remove_error}"));
                    }
                }
                let detail = if rollback_errors.is_empty() {
                    String::new()
                } else {
                    format!("；回滚未完成：{}", rollback_errors.join("；"))
                };
                return Err(format!("{svc}: {error}{detail}"));
            }
        }
        *self.state.lock().unwrap() = Some(port);
        Ok(())
    }

    /// When TUN suspended another client's proxy, transfer that original
    /// snapshot to Crossbow's proxy journal without briefly re-enabling it.
    /// The two Crossbow switches can then be controlled independently.
    pub fn enable_during_tun(&self, port: u16) -> Result<(), String> {
        let tun_journal = self.tun_journal_path();
        let saved = match std::fs::read(&tun_journal) {
            Ok(saved) => saved,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                return self.enable(port);
            }
            Err(error) => return Err(format!("读取 TUN 代理恢复日志失败：{error}")),
        };
        if self.journal_path.exists() {
            return Err("系统代理恢复日志已存在，无法接管 TUN 暂停的代理".into());
        }
        let suspended: SuspendedSysProxy = serde_json::from_slice(&saved)
            .map_err(|error| format!("read TUN proxy journal: {error}"))?;
        let original = if suspended.enabled_port.is_some() {
            let raw = suspended
                .journal
                .as_deref()
                .ok_or("TUN 代理恢复日志缺少原始系统代理快照")?;
            serde_json::from_slice::<Journal>(raw)
                .map_err(|error| format!("解析原始系统代理快照失败：{error}"))?
                .snapshot
        } else {
            suspended.snapshot
        };
        let services = self.backend.list_services()?;
        if services.is_empty() {
            return Err("no network services found".into());
        }
        let mut current = BTreeMap::new();
        for service in &services {
            current.insert(service.clone(), self.backend.service_snapshot(service)?);
        }
        self.write_journal(port, &original)?;
        let result = services
            .iter()
            .try_for_each(|service| self.backend.enable_service(service, port))
            .and_then(|()| {
                std::fs::remove_file(&tun_journal)
                    .map_err(|error| format!("清理 TUN 代理恢复日志失败：{error}"))
            });
        if let Err(error) = result {
            let mut rollback_errors = Vec::new();
            for (service, snapshot) in &current {
                if let Err(restore_error) = self.backend.restore_service(service, snapshot) {
                    rollback_errors.push(format!("{service}: {restore_error}"));
                }
            }
            if rollback_errors.is_empty() {
                let _ = std::fs::remove_file(&self.journal_path);
            }
            let rollback = if rollback_errors.is_empty() {
                String::new()
            } else {
                format!("；回滚未完成：{}", rollback_errors.join("；"))
            };
            return Err(format!("开启系统代理失败：{error}{rollback}"));
        }
        *self.state.lock().unwrap() = Some(port);
        Ok(())
    }

    /// While TUN remains on, disabling Crossbow's proxy must leave macOS
    /// proxy settings off. Defer the pre-Crossbow snapshot until TUN exits.
    pub fn disable_during_tun(&self) -> Result<(), String> {
        if self.state.lock().unwrap().is_none() {
            return Ok(());
        }
        let journal = self
            .read_journal()
            .ok_or("系统代理恢复日志无法读取，未覆盖现有代理设置")?;
        let tun_journal = self.tun_journal_path();
        let previous_tun_journal = match std::fs::read(&tun_journal) {
            Ok(saved) => Some(saved),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => None,
            Err(error) => return Err(format!("读取 TUN 代理恢复日志失败：{error}")),
        };
        let services = self.backend.list_services()?;
        let mut current = BTreeMap::new();
        for service in &services {
            current.insert(service.clone(), self.backend.service_snapshot(service)?);
        }
        let suspended = SuspendedSysProxy {
            snapshot: journal.snapshot,
            journal: None,
            enabled_port: None,
        };
        if previous_tun_journal.is_none() {
            std::fs::write(
                &tun_journal,
                serde_json::to_vec(&suspended).map_err(|error| error.to_string())?,
            )
            .map_err(|error| format!("保存 TUN 代理恢复日志失败：{error}"))?;
        }
        let result = services
            .iter()
            .try_for_each(|service| self.backend.disable_service(service))
            .and_then(|()| {
                std::fs::remove_file(&self.journal_path)
                    .map_err(|error| format!("清理系统代理恢复日志失败：{error}"))
            });
        if let Err(error) = result {
            let mut rollback_errors = Vec::new();
            for (service, snapshot) in &current {
                if let Err(restore_error) = self.backend.restore_service(service, snapshot) {
                    rollback_errors.push(format!("{service}: {restore_error}"));
                }
            }
            if previous_tun_journal.is_none() && rollback_errors.is_empty() {
                let _ = std::fs::remove_file(&tun_journal);
            }
            let rollback = if rollback_errors.is_empty() {
                String::new()
            } else {
                format!("；回滚未完成：{}", rollback_errors.join("；"))
            };
            return Err(format!("关闭系统代理失败：{error}{rollback}"));
        }
        *self.state.lock().unwrap() = None;
        Ok(())
    }

    /// 还原代理设置：优先按 journal 里的原设置快照逐服务恢复；无快照（老格式
    /// 或快照失败）退回全量关闭。幂等，用于退出兜底。
    pub fn disable(&self) -> Result<(), String> {
        let journal = self.read_journal();
        if self.journal_path.exists() && journal.is_none() {
            return Err("系统代理恢复日志无法读取，未覆盖现有代理设置".into());
        }
        if journal.is_none() && self.state.lock().unwrap().is_none() {
            // Crossbow does not own the current proxy. In particular, exiting
            // while TUN is active must not clear another client's settings.
            return Ok(());
        }
        let mut errors = Vec::new();
        if let Some(snapshot) = journal.map(|j| j.snapshot).filter(|s| !s.is_empty()) {
            for (svc, snap) in &snapshot {
                if let Err(error) = self.backend.restore_service(svc, snap) {
                    errors.push(format!("{svc}: {error}"));
                }
            }
        } else {
            for svc in self.backend.list_services()? {
                if let Err(error) = self.backend.disable_service(&svc) {
                    errors.push(format!("{svc}: {error}"));
                }
            }
        }
        if !errors.is_empty() {
            // Preserve the journal and enabled state so a later attempt can
            // finish restoring every service after a transient failure.
            return Err(format!("还原系统代理失败：{}", errors.join("；")));
        }
        if let Err(error) = std::fs::remove_file(&self.journal_path) {
            if error.kind() != std::io::ErrorKind::NotFound {
                return Err(format!("清理系统代理恢复日志失败：{error}"));
            }
        }
        *self.state.lock().unwrap() = None;
        Ok(())
    }

    /// TUN must leave every network service with its system proxy disabled.
    /// `disable` restores the pre-Crossbow snapshot, which may point to an old
    /// local proxy with no listener and keep browsers offline even while TUN
    /// itself is healthy.
    pub fn suspend_for_tun(&self) -> Result<SuspendedSysProxy, String> {
        let tun_journal = self.tun_journal_path();
        if let Ok(saved) = std::fs::read(&tun_journal) {
            let suspended = serde_json::from_slice(&saved)
                .map_err(|error| format!("read TUN proxy journal: {error}"))?;
            // Another proxy client may re-enable its system proxy while TUN is
            // running. Keep the original snapshot, but clear the live settings.
            for service in self.backend.list_services()? {
                let live = self.backend.service_snapshot(&service)?;
                if live.web.is_some() || live.secure.is_some() || live.socks.is_some() {
                    self.backend.disable_service(&service)?;
                }
            }
            return Ok(suspended);
        }
        let services = self.backend.list_services()?;
        if services.is_empty() {
            return Err("no network services found".into());
        }
        let mut snapshot = BTreeMap::new();
        for service in &services {
            snapshot.insert(service.clone(), self.backend.service_snapshot(service)?);
        }
        let suspended = SuspendedSysProxy {
            snapshot,
            journal: std::fs::read(&self.journal_path).ok(),
            enabled_port: *self.state.lock().unwrap(),
        };
        let journal = serde_json::to_vec(&suspended)
            .map_err(|error| format!("serialize TUN proxy journal: {error}"))?;
        std::fs::write(&tun_journal, journal)
            .map_err(|error| format!("save TUN proxy journal: {error}"))?;
        for service in &services {
            if let Err(error) = self.backend.disable_service(service) {
                for (name, original) in &suspended.snapshot {
                    let _ = self.backend.restore_service(name, original);
                }
                let _ = std::fs::remove_file(&tun_journal);
                return Err(format!(
                    "disable system proxy for TUN on {service}: {error}"
                ));
            }
        }
        *self.state.lock().unwrap() = None;
        let _ = std::fs::remove_file(&self.journal_path);
        Ok(suspended)
    }

    /// Restore the exact pre-TUN settings after either a failed start or a
    /// successful exit from TUN. Keep the journal if restoration fails.
    pub fn restore_after_failed_tun(&self, suspended: SuspendedSysProxy) -> Result<(), String> {
        for (service, original) in &suspended.snapshot {
            self.backend.restore_service(service, original)?;
        }
        match suspended.journal {
            Some(journal) => std::fs::write(&self.journal_path, journal)
                .map_err(|error| format!("restore system proxy journal: {error}"))?,
            None => {
                let _ = std::fs::remove_file(&self.journal_path);
            }
        }
        *self.state.lock().unwrap() = suspended.enabled_port;
        std::fs::remove_file(self.tun_journal_path())
            .map_err(|error| format!("remove TUN proxy journal: {error}"))?;
        Ok(())
    }

    pub fn restore_after_tun(&self) -> Result<(), String> {
        if self.state.lock().unwrap().is_some() {
            return Ok(());
        }
        let path = self.tun_journal_path();
        let Ok(saved) = std::fs::read(path) else {
            return Ok(());
        };
        let suspended = serde_json::from_slice(&saved)
            .map_err(|error| format!("read TUN proxy journal: {error}"))?;
        self.restore_after_failed_tun(suspended)
    }

    /// A cold launch has no Crossbow listener yet. If Crossbow owned the
    /// pre-TUN proxy, restore the settings that preceded Crossbow instead of
    /// pointing the system at its now-dead mixed port.
    pub fn recover_tun_without_core(&self) -> Result<(), String> {
        let path = self.tun_journal_path();
        let Ok(saved) = std::fs::read(path) else {
            return Ok(());
        };
        let mut suspended: SuspendedSysProxy = serde_json::from_slice(&saved)
            .map_err(|error| format!("read TUN proxy journal: {error}"))?;
        if suspended.enabled_port.is_some() {
            suspended.snapshot = suspended
                .journal
                .as_deref()
                .and_then(|raw| serde_json::from_slice::<Journal>(raw).ok())
                .map(|journal| journal.snapshot)
                .unwrap_or_default();
            suspended.journal = None;
            suspended.enabled_port = None;
        }
        self.restore_after_failed_tun(suspended)
    }

    /// 各服务当前生效的 HTTP/HTTPS/SOCKS 代理端点（含第三方设置的）。
    /// 诊断用：判断系统代理是否指向本应用端口、是否存在第三方冲突。
    pub fn external_endpoints(&self) -> Vec<(String, ProxyEndpoint)> {
        let mut out = Vec::new();
        if let Ok(services) = self.backend.list_services() {
            for svc in &services {
                if let Ok(snap) = self.backend.service_snapshot(svc) {
                    if let Some(ep) = snap.web {
                        out.push((svc.clone(), ep));
                    }
                    if let Some(ep) = snap.secure {
                        out.push((svc.clone(), ep));
                    }
                    if let Some(ep) = snap.socks {
                        out.push((svc.clone(), ep));
                    }
                }
            }
        }
        out
    }

    pub fn status(&self) -> SysProxyStatus {
        match *self.state.lock().unwrap() {
            Some(port) => SysProxyStatus {
                enabled: true,
                port,
            },
            None => SysProxyStatus {
                enabled: false,
                port: 0,
            },
        }
    }

    /// 收养场景：轻量交接退出时系统代理保持开启（journal 留存），
    /// 本次启动若内核被成功收养，则从 journal 恢复内存状态而不是还原设置。
    /// 返回收养的端口。
    pub fn adopt_from_journal(&self) -> Option<u16> {
        let j = self.read_journal()?;
        if j.port == 0 {
            return None; // v1 兼容格式无端口信息，走 recover_stale 路径
        }
        *self.state.lock().unwrap() = Some(j.port);
        Some(j.port)
    }

    /// 启动时兜底：上次会话残留的开启状态 → 还原原设置。返回是否发生了还原。
    pub fn recover_stale(&self) -> bool {
        if !self.journal_path.exists() {
            return false;
        }
        if let Err(error) = self.disable() {
            eprintln!("sysproxy stale recovery failed: {error}");
            false
        } else {
            true
        }
    }

    fn read_journal(&self) -> Option<Journal> {
        let raw = std::fs::read_to_string(&self.journal_path).ok()?;
        // 兼容 v1（enabled+port，无 snapshot）：退化到全量关闭路径。
        if let Ok(j) = serde_json::from_str::<Journal>(&raw) {
            return Some(j);
        }
        serde_json::from_str::<serde_json::Value>(&raw)
            .ok()
            .map(|_| Journal {
                port: 0,
                snapshot: BTreeMap::new(),
            })
    }

    fn write_journal(
        &self,
        port: u16,
        snapshot: &BTreeMap<String, ServiceSnapshot>,
    ) -> Result<(), String> {
        let j = Journal {
            port,
            snapshot: snapshot.clone(),
        };
        if let Some(parent) = self.journal_path.parent() {
            std::fs::create_dir_all(parent).map_err(|e| format!("创建代理恢复目录失败: {e}"))?;
        }
        std::fs::write(
            &self.journal_path,
            serde_json::to_vec(&j).map_err(|e| format!("序列化代理恢复日志失败: {e}"))?,
        )
        .map_err(|e| format!("写入代理恢复日志失败: {e}"))
    }
}

/// 解析 `-listallnetworkservices` 输出：跳过说明行，跳过禁用（`*`）服务。
fn parse_services(output: &str) -> Vec<String> {
    output
        .lines()
        .skip(1) // "An asterisk (*) denotes..."
        .map(str::trim)
        .filter(|l| !l.is_empty() && !l.starts_with('*'))
        .map(str::to_string)
        .collect()
}

/// `networksetup -getproxybypassdomains` 在没有条目时输出一句说明，
/// 有条目时每行一个域名。空列表仍需作为快照保存，恢复时传入 Empty。
#[cfg(target_os = "macos")]
fn parse_bypass_domains(output: &str) -> Vec<String> {
    let lines = output
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty());
    lines
        .filter(|line| {
            !line.starts_with("There aren't any bypass domains")
                && !line.starts_with("There are no bypass domains")
                && !line.starts_with("Domains bypassed by the proxy server:")
        })
        .map(str::to_string)
        .collect()
}

/// 解析 `-getwebproxy` 类输出为槽位设置；未启用返回 None。
fn parse_endpoint(output: &str) -> Option<ProxyEndpoint> {
    let mut enabled = false;
    let mut host = String::new();
    let mut port = 0u16;
    for line in output.lines() {
        let line = line.trim();
        if let Some(v) = line.strip_prefix("Enabled:") {
            enabled = v.trim() == "Yes";
        } else if let Some(v) = line.strip_prefix("Server:") {
            host = v.trim().to_string();
        } else if let Some(v) = line.strip_prefix("Port:") {
            port = v.trim().parse().unwrap_or(0);
        }
    }
    (enabled && port > 0).then_some(ProxyEndpoint { host, port })
}

/// 解析 `-getwebproxy` 输出中的 Enabled 行。
#[cfg(test)]
fn parse_proxy_enabled(output: &str) -> bool {
    output.lines().any(|l| {
        let l = l.trim();
        l.starts_with("Enabled:") && l.ends_with("Yes")
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;
    use std::sync::Arc;

    #[test]
    fn windows_protocol_map_and_single_server_are_parsed_exactly() {
        let settings = WindowsProxyConfig {
            flags: 3,
            server: "http=127.0.0.1:7897;https=127.0.0.1:7898;socks=[::1]:7899".into(),
            ..WindowsProxyConfig::default()
        };
        assert_eq!(
            settings.endpoint("https"),
            Some(ProxyEndpoint {
                host: "127.0.0.1".into(),
                port: 7898
            })
        );
        assert_eq!(
            settings.endpoint("socks"),
            Some(ProxyEndpoint {
                host: "::1".into(),
                port: 7899
            })
        );
        let single = WindowsProxyConfig {
            server: "localhost:7897".into(),
            ..settings.clone()
        };
        assert_eq!(single.endpoint("https").unwrap().port, 7897);
        let off = WindowsProxyConfig {
            flags: 1,
            ..settings
        };
        assert_eq!(off.endpoint("https"), None);
    }

    #[test]
    fn windows_pac_and_bypass_survive_proxy_journal_roundtrip() {
        let dir = tempfile::tempdir().unwrap();
        let original = ServiceSnapshot {
            windows: Some(WindowsProxyConfig {
                flags: 13,
                server: "http=proxy.example:8080;https=secure.example:8443".into(),
                bypass: "<local>;*.example;host with spaces".into(),
                pac_url: "https://config.example/proxy.pac".into(),
            }),
            ..ServiceSnapshot::default()
        };
        let backend = FakeBackend::new(&["Windows"]).with_preset("Windows", original.clone());
        let manager = manager_with(backend.clone(), &dir);
        manager.enable(7897).unwrap();
        manager.disable().unwrap();
        assert_eq!(
            backend.inner.restored.lock().unwrap().get("Windows"),
            Some(&original)
        );
        let legacy: ServiceSnapshot =
            serde_json::from_str(r#"{"web":null,"secure":null,"socks":null,"bypass":"<local>"}"#)
                .unwrap();
        assert!(legacy.windows.is_none());
    }

    #[test]
    fn parses_service_list_skipping_disabled() {
        let out = "An asterisk (*) denotes that a network service is disabled.\nWi-Fi\n*Disabled LAN\nThunderbolt Bridge\n\n";
        assert_eq!(
            parse_services(out),
            vec!["Wi-Fi".to_string(), "Thunderbolt Bridge".to_string()]
        );
    }

    #[test]
    fn parses_enabled_flag() {
        assert!(parse_proxy_enabled(
            "Enabled: Yes\nServer: 127.0.0.1\nPort: 7897\n"
        ));
        assert!(!parse_proxy_enabled("Enabled: No\nServer: \nPort: 0\n"));
    }

    #[test]
    fn parses_endpoint_from_getwebproxy_output() {
        let ep = parse_endpoint(
            "Enabled: Yes\nServer: 127.0.0.1\nPort: 7890\nAuthenticated Proxy Enabled: 0\n",
        )
        .unwrap();
        assert_eq!(ep.host, "127.0.0.1");
        assert_eq!(ep.port, 7890);
        assert!(parse_endpoint("Enabled: No\nServer: \nPort: 0\n").is_none());
    }

    #[derive(Clone)]
    struct FakeBackend {
        inner: Arc<FakeState>,
    }

    struct FakeState {
        services: Vec<String>,
        enabled: Mutex<HashSet<String>>,
        fail_on: Mutex<Vec<String>>,
        /// 各服务 enable 前的原设置（模拟第三方客户端已配置的场景）。
        presets: Mutex<BTreeMap<String, ServiceSnapshot>>,
        /// restore_service 调用记录（断言还原内容用）。
        restored: Mutex<BTreeMap<String, ServiceSnapshot>>,
    }

    impl FakeBackend {
        fn new(services: &[&str]) -> Self {
            Self {
                inner: Arc::new(FakeState {
                    services: services.iter().map(|s| s.to_string()).collect(),
                    enabled: Mutex::new(HashSet::new()),
                    fail_on: Mutex::new(vec![]),
                    presets: Mutex::new(BTreeMap::new()),
                    restored: Mutex::new(BTreeMap::new()),
                }),
            }
        }

        fn with_preset(self, service: &str, snap: ServiceSnapshot) -> Self {
            self.inner
                .presets
                .lock()
                .unwrap()
                .insert(service.to_string(), snap);
            self
        }
    }

    impl SysProxyBackend for FakeBackend {
        fn list_services(&self) -> Result<Vec<String>, String> {
            Ok(self.inner.services.clone())
        }
        fn enable_service(&self, service: &str, _port: u16) -> Result<(), String> {
            if self
                .inner
                .fail_on
                .lock()
                .unwrap()
                .iter()
                .any(|s| s == service)
            {
                return Err(format!("boom on {service}"));
            }
            self.inner
                .enabled
                .lock()
                .unwrap()
                .insert(service.to_string());
            Ok(())
        }
        fn disable_service(&self, service: &str) -> Result<(), String> {
            self.inner.enabled.lock().unwrap().remove(service);
            Ok(())
        }
        fn service_snapshot(&self, service: &str) -> Result<ServiceSnapshot, String> {
            Ok(self
                .inner
                .presets
                .lock()
                .unwrap()
                .get(service)
                .cloned()
                .unwrap_or_default())
        }
        fn restore_service(&self, service: &str, snap: &ServiceSnapshot) -> Result<(), String> {
            self.inner
                .restored
                .lock()
                .unwrap()
                .insert(service.to_string(), snap.clone());
            Ok(())
        }
    }

    type FakeManager = SysProxyManager<FakeBackend>;

    fn manager_with(backend: FakeBackend, dir: &tempfile::TempDir) -> FakeManager {
        SysProxyManager::new(backend, dir.path().join("journal.json"))
    }

    #[test]
    fn enable_writes_journal_disable_clears() {
        let dir = tempfile::tempdir().unwrap();
        let mgr = manager_with(FakeBackend::new(&["Wi-Fi", "Ethernet"]), &dir);
        mgr.enable(7897).unwrap();
        assert!(mgr.status().enabled);
        assert_eq!(mgr.status().port, 7897);
        assert!(dir.path().join("journal.json").exists());

        mgr.disable().unwrap();
        assert!(!mgr.status().enabled);
        assert!(!dir.path().join("journal.json").exists());
    }

    #[test]
    fn enable_all_failed_is_error() {
        let dir = tempfile::tempdir().unwrap();
        let b = FakeBackend::new(&["Wi-Fi"]);
        b.inner.fail_on.lock().unwrap().push("Wi-Fi".into());
        let mgr = manager_with(b, &dir);
        assert!(mgr.enable(7897).is_err());
        assert!(!mgr.status().enabled);
    }

    #[test]
    fn stale_journal_triggers_restore() {
        let dir = tempfile::tempdir().unwrap();
        // 第一次会话：开启后「崩溃」（manager 直接丢弃，journal 残留）。
        {
            let mgr = manager_with(FakeBackend::new(&["Wi-Fi"]), &dir);
            let _ = mgr.enable(7897);
        }
        assert!(dir.path().join("journal.json").exists());

        // 第二次会话启动：识别残留并还原。
        let mgr = manager_with(FakeBackend::new(&["Wi-Fi"]), &dir);
        assert!(mgr.recover_stale());
        assert!(!dir.path().join("journal.json").exists());
    }

    /// 关闭时按快照还原第三方客户端的原设置（而不是一刀切关掉）。
    #[test]
    fn disable_restores_original_settings() {
        let dir = tempfile::tempdir().unwrap();
        let preset = ServiceSnapshot {
            windows: None,
            bypass: None,
            web: Some(ProxyEndpoint {
                host: "127.0.0.1".into(),
                port: 7890,
            }),
            secure: None,
            socks: None,
        };
        let backend = FakeBackend::new(&["Wi-Fi"]).with_preset("Wi-Fi", preset.clone());
        let mgr = manager_with(backend.clone(), &dir);
        mgr.enable(7897).unwrap();
        mgr.disable().unwrap();

        let restored = backend.inner.restored.lock().unwrap();
        let snap = restored.get("Wi-Fi").expect("restore called");
        assert_eq!(
            snap.web,
            Some(ProxyEndpoint {
                host: "127.0.0.1".into(),
                port: 7890,
            })
        );
        assert_eq!(snap.secure, None);
    }

    /// 无原设置（原本全关）时，关闭走逐服务还原路径且各槽位归零（等价全关）。
    #[test]
    fn disable_with_empty_preset_restores_off() {
        let dir = tempfile::tempdir().unwrap();
        let backend = FakeBackend::new(&["Wi-Fi"]);
        let mgr = manager_with(backend.clone(), &dir);
        mgr.enable(7897).unwrap();
        mgr.disable().unwrap();
        let restored = backend.inner.restored.lock().unwrap();
        let snap = restored.get("Wi-Fi").expect("restore called");
        assert_eq!(*snap, ServiceSnapshot::default());
        assert!(!dir.path().join("journal.json").exists());
    }

    /// macOS 专属测试（networksetup 后端）——测试模块需在 Windows 上
    /// 编译（统一通知的 CI 回归步骤跨平台跑），此处的 NetworkSetup
    /// 引用必须随平台门控，否则 Windows 编译失败。
    #[cfg(target_os = "macos")]
    mod macos_networksetup {
        use super::*;

        /// 真实切换一次系统代理并还原（改动本机 networksetup 设置，测试结束即还原）。
        /// 防护：若当前已有任何服务开启了代理（用户可能在用别的客户端），直接跳过。
        #[test]
        #[ignore = "touches real system proxy settings"]
        fn live_networksetup_toggle_and_restore() {
            let services = NetworkSetup.list_services().unwrap();
            assert!(!services.is_empty(), "no network services found");
            let already_on = services.iter().any(|svc| {
                NetworkSetup::run(&["-getwebproxy", svc])
                    .map(|out| parse_proxy_enabled(&out))
                    .unwrap_or(false)
            });
            if already_on {
                eprintln!("skip: system proxy already in use by another client");
                return;
            }

            let dir = tempfile::tempdir().unwrap();
            let mgr = SysProxyManager::new(NetworkSetup, dir.path().join("journal.json"));
            mgr.enable(17899).unwrap();
            assert!(mgr.status().enabled);
            let out = NetworkSetup::run(&["-getwebproxy", &services[0]]).unwrap();
            assert!(parse_proxy_enabled(&out), "proxy should be enabled");

            mgr.disable().unwrap();
            let out = NetworkSetup::run(&["-getwebproxy", &services[0]]).unwrap();
            assert!(!parse_proxy_enabled(&out), "proxy should be restored");
        }
    }
}
